-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tempo de Geração: Mar 19, 2021 as 03:09 PM
-- Versão do Servidor: 5.0.45
-- Versão do PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Banco de Dados: `pedidos`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `cliente`
-- 

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(40) NOT NULL,
  `cidade` varchar(40) NOT NULL,
  `estado` varchar(2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `cliente`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `estados`
-- 

CREATE TABLE `estados` (
  `UF` varchar(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Extraindo dados da tabela `estados`
-- 

INSERT INTO `estados` VALUES ('AC');
INSERT INTO `estados` VALUES ('AL');
INSERT INTO `estados` VALUES ('AP');
INSERT INTO `estados` VALUES ('AM');
INSERT INTO `estados` VALUES ('BA');
INSERT INTO `estados` VALUES ('CE');
INSERT INTO `estados` VALUES ('DF');
INSERT INTO `estados` VALUES ('ES');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `npedido`
-- 

CREATE TABLE `npedido` (
  `n` varchar(11) NOT NULL,
  PRIMARY KEY  (`n`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Extraindo dados da tabela `npedido`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `numero`
-- 

CREATE TABLE `numero` (
  `PRODUTO` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Extraindo dados da tabela `numero`
-- 

INSERT INTO `numero` VALUES ('1');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `produto`
-- 

CREATE TABLE `produto` (
  `idp` int(11) NOT NULL auto_increment,
  `idc` int(11) NOT NULL,
  `npedido` varchar(10) NOT NULL,
  `descricao` varchar(80) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `valorun` float NOT NULL,
  `ValorTotal` float NOT NULL,
  PRIMARY KEY  (`idp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `produto`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `registrogeral`
-- 

CREATE TABLE `registrogeral` (
  `id` int(10) NOT NULL auto_increment,
  `npedido` varchar(10) NOT NULL,
  `data` date NOT NULL,
  `cliente` int(11) NOT NULL,
  `total` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `registrogeral`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `temp`
-- 

CREATE TABLE `temp` (
  `id` int(11) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `qt` int(11) NOT NULL,
  `vu` float NOT NULL,
  `vt` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Extraindo dados da tabela `temp`
-- 

